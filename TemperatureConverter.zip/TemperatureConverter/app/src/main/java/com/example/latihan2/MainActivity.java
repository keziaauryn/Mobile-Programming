package com.example.latihan2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText TemperatureInput;
    TextView celciusInput;
    TextView reamurInput;
    TextView fahrenheitInput;
    TextView kelvinInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TemperatureInput = findViewById(R.id.TempText);
        celciusInput=findViewById(R.id.CelciusInput);
        reamurInput=findViewById(R.id.ReamurInput);
        fahrenheitInput=findViewById(R.id.FahrenheitInput);
        kelvinInput=findViewById(R.id.KelvinInput);
    }

    public void ConverseTemperature(View view) {
        Float celcius = Float.parseFloat(TemperatureInput.getText().toString());
        Float reamur = (celcius * 4) / 5;
        Float kelvin = celcius + 273;
        Float fahrenheit = ((celcius * 9) / 5 ) + 32;

        celciusInput.setText(TemperatureInput.getText());
        reamurInput.setText(reamur.toString());
        kelvinInput.setText(kelvin.toString());
        fahrenheitInput.setText(fahrenheit.toString());
    }
}